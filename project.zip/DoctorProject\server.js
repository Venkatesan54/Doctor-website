/**
 * SECURITY PROXY SERVER
 * -------------------------------------------------------------
 * This is a lightweight Node.js Express server to proxy OpenAI requests.
 * By moving the VITE_OPENAI_API_KEY from the React bundle to this backend file,
 * we prevent malicious users from stealing your API key via their browsers.
 * 
 * To run this server: 
 * 1. npm install express cors dotenv node-fetch
 * 2. node server.js
 */

const express = require('express');
const cors = require('cors');
require('dotenv').config(); // Load the API key from a private .env file

const app = express();
app.use(cors());
app.use(express.json());

const OPENAI_API_KEY = process.env.OPENAI_API_KEY || process.env.VITE_OPENAI_API_KEY || "AIzaSyCkNi3QtmAgRIidePdF9D5_GtV-yTBW-XE";

app.post('/api/chat', async (req, res) => {
  try {
    const { question, conversation } = req.body;

    // Optional: Add rate limiting, abuse detection, and user authentication here!

    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: conversation ? conversation.map(m => ({ role: m.role, content: m.text })) : [{ role: "user", content: question }],
        max_tokens: 350,
        temperature: 0.75,
      }),
    });

    if (!response.ok) {
      throw new Error(`OpenAI API responded with status ${response.status}`);
    }

    const data = await response.json();
    const answer = data?.choices?.[0]?.message?.content?.trim() || "No response generated.";

    res.json({ reply: answer });

  } catch (error) {
    console.error("Backend Proxy Error:", error);
    res.status(500).json({ reply: "Internal server error connecting to the AI." });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Security Proxy Server running on http://localhost:${PORT}`);
});
