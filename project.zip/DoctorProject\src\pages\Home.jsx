import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Activity, CheckCircle, Star, ArrowRight, Shield, Clock, Heart, Award } from "lucide-react";


const specialties = [
  { emoji: "🫀", name: "Cardiology", count: "45+ Doctors" },
  { emoji: "🧠", name: "Neurology", count: "30+ Doctors" },
  { emoji: "🦷", name: "Dentistry", count: "60+ Doctors" },
  { emoji: "👁️", name: "Ophthalmology", count: "25+ Doctors" },
  { emoji: "🩺", name: "General", count: "120+ Doctors" },
  { emoji: "🦴", name: "Orthopedics", count: "38+ Doctors" },
  { emoji: "🌸", name: "Dermatology", count: "42+ Doctors" },
  { emoji: "👶", name: "Pediatrics", count: "55+ Doctors" },
];

const stats = [
  { value: "50k+", label: "Happy Patients" },
  { value: "500+", label: "Expert Doctors" },
  { value: "98%", label: "Satisfaction Rate" },
  { value: "24/7", label: "Support Available" },
];

const Home = () => {
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const handleSearch = () => {
    if (!search.trim()) return;
    navigate(`/doctors?q=${encodeURIComponent(search)}`);
  };

  return (
    <main className="min-h-screen bg-slate-50 dark:bg-slate-900">

      {/* HERO */}
      <section className="relative pt-32 pb-24 overflow-hidden bg-white dark:bg-slate-800">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-50/30 dark:bg-blue-900/30 -skew-x-12 translate-x-1/4" />
        <div className="absolute top-1/4 left-10 w-64 h-64 rounded-full bg-medical-blue opacity-5 blur-[120px]" />

        <div className="relative z-10 max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-16">

            {/* LEFT */}
            <div className="flex-1 text-center lg:text-left space-y-10 animate-fade-in [animation-delay:200ms]">
              <div className="inline-flex items-center gap-2 px-5 py-2 rounded-2xl text-sm font-bold bg-blue-50 dark:bg-blue-900 text-medical-blue border">
                Trusted by 50,000+ Patients
              </div>

              <h1 className="text-5xl lg:text-7xl font-black text-slate-900 dark:text-white">
                Book Your Top <br />
                <span className="gradient-text">Specialist Today</span>
              </h1>

              <p className="text-xl text-slate-600 dark:text-slate-300 max-w-xl">
                Connect with verified doctors instantly and manage your health easily.
              </p>

              {/* SEARCH */}
              <div className="flex flex-col sm:flex-row gap-3 bg-white dark:bg-slate-700 p-2 rounded-2xl shadow border max-w-xl transition-all focus-within:ring-2 focus-within:ring-blue-500 focus-within:border-transparent hover:shadow-md">
                <input
                  className="flex-1 px-4 py-3 outline-none text-slate-900 dark:text-white placeholder-slate-500 dark:placeholder-slate-400"
                  placeholder="Search doctors..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
                <button
                  onClick={handleSearch}
                  className="bg-medical-blue text-white px-6 py-3 sm:py-0 shrink-0 rounded-xl hover:bg-blue-700 dark:hover:bg-blue-800"
                >
                  Search
                </button>
              </div>

              {/* STATS */}
              <div className="flex gap-6 flex-wrap">
                {stats.map((s) => (
                  <div key={s.label}>
                    <p className="text-2xl font-bold text-slate-900 dark:text-white">{s.value}</p>
                    <p className="text-xs text-gray-400 dark:text-slate-500">{s.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* RIGHT IMAGE */}
            <div className="flex-1 animate-fade-in [animation-delay:400ms]">
              <img
                src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=1000&q=80&auto=format&fm=webp"
                alt="Medical professional consulting with a patient in a modern clinical setting"
                fetchpriority="high"
                className="rounded-3xl shadow-xl"
              />
            </div>

          </div>
        </div>
      </section>

      {/* SPECIALTIES */}
      <section className="py-20 bg-slate-50 dark:bg-slate-900">
        <div className="max-w-7xl mx-auto px-4">

          <div className="flex justify-between items-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-slate-900 dark:text-white">Specialties</h2>
            <Link to="/doctors" className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
              View All <ArrowRight size={16} />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 animate-fade-in">
            {specialties.map((spec) => (
              <Link
                key={spec.name}
                to={`/doctors?specialty=${encodeURIComponent(spec.name)}`}
                className="p-6 bg-white dark:bg-slate-800 rounded-xl shadow text-center hover:shadow-lg text-slate-900 dark:text-white hover-lift"
              >
                <div className="text-3xl">{spec.emoji}</div>
                <p className="font-bold mt-2">{spec.name}</p>
                <p className="text-sm text-gray-400 dark:text-slate-500">{spec.count}</p>
              </Link>
            ))}
          </div>

        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-20 bg-white dark:bg-slate-800 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-10 text-slate-900 dark:text-white">How It Works</h2>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div>
            <Activity size={40} className="mx-auto mb-4 text-blue-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">Search Doctor</h3>
            <p className="text-slate-600 dark:text-slate-300">Find specialists easily</p>
          </div>

          <div>
            <Clock size={40} className="mx-auto mb-4 text-green-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">Book Appointment</h3>
            <p className="text-slate-600 dark:text-slate-300">Select your time slot</p>
          </div>

          <div>
            <Shield size={40} className="mx-auto mb-4 text-purple-500" />
            <h3 className="font-bold text-slate-900 dark:text-white">Secure Consultation</h3>
            <p className="text-slate-600 dark:text-slate-300">Safe and verified service</p>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 text-center bg-slate-900 dark:bg-slate-800 text-white animate-fade-in">
        <h2 className="text-3xl md:text-4xl font-bold mb-6">Find Nearby Hospitals</h2>

        <Link
          to="/find-nearby"
          className="bg-blue-500 px-8 py-4 rounded-xl hover:bg-blue-600 dark:hover:bg-blue-700"
        >
          Explore Nearby
        </Link>
      </section>



    </main>
  );
};

export default Home;